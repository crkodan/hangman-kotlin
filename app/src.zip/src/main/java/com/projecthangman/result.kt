package com.projecthangman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_result.*
import android.view.Window
import android.view.WindowManager

class result : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val int = this.intent
        val ucapan = int.getStringExtra("rslts")
        val scr = int.getStringExtra("scores")
        textViewUcapan.text = ucapan
        textViewResult.text = "total score: $scr"

        btnHome.setOnClickListener{
            val intss = Intent(this,MainActivity::class.java)
            startActivity(intss)
        }
    }
}
