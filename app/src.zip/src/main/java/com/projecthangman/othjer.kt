package com.projecthangman

import android.content.Intent
import android.widget.Button
import kotlinx.android.synthetic.main.activity_game.*
import org.jetbrains.anko.toast

class othjer {
    //    val arrayofTebakan = arrayListOf<String>()
//    val jawabanSungguhan = arrayListOf<String>()
//    var jawaban = ""
//    for(items in soal){
//        if(items.theme == theme && items.difficult == diff){
//            var rnd = (0 until items.array.size).random()
//            var guess = items.array[rnd]
//            // isi karakter yang harus dijawab
//            guess.forEach { arrayofTebakan.add(it.toString()) }
//            // isi karakter yang ditampilkan user atau soal untuk user
//            arrayofTebakan.forEach{jawabanSungguhan.add("_")}
//        }
//    }
//    for (i in 0 until jawabanSungguhan.size){
//        jawaban += jawabanSungguhan[i]+" "
//    }
//    textView2.text = jawaban
//    cekPencet(buttonA)
//    cekPencet(buttonB)
//    cekPencet(buttonC)
//    cekPencet(buttonD)
//    cekPencet(buttonE)
//    cekPencet(buttonF)
//    cekPencet(buttonG)
//    cekPencet(buttonH)
//    cekPencet(buttonI)
//    cekPencet(buttonJ)
//    cekPencet(buttonK)
//    cekPencet(buttonL)
//    cekPencet(buttonM)
//    cekPencet(buttonN)
//    cekPencet(buttonO)
//    cekPencet(buttonP)
//    cekPencet(buttonQ)
//    cekPencet(buttonR)
//    cekPencet(buttonS)
//    cekPencet(buttonT)
//    cekPencet(buttonU)
//    cekPencet(buttonV)
//    cekPencet(buttonW)
//    cekPencet(buttonX)
//    cekPencet(buttonY)
//    cekPencet(buttonZ)
//}
//fun cekMenang(){
//    var terjawab = true
//    jawabanSungguhan.forEach{c ->
//        if(!arrayofTebakan.contains(c))
//            terjawab = false
//    }
//    if(terjawab){
//        val intent = Intent(this,result::class.java)
//        var menang = "SELAMAT ANDA TELAH MEMENANGKAN GAME INI!!!!"
//        intent.putExtra("menang",menang)
//        startActivity(intent)
//    }
//}
//
//fun cekPencet(button: Button) {
//    button.setOnClickListener {
//        it as Button
//        var jawaban = ""
//        var result = 0
//        var cek = false
//        var kalah ="oh my, the man has been hanged"
//        for (i in 0 until arrayofTebakan.size) {
//
//            if (arrayofTebakan[i].equals(it.text.toString(), true)) {
//                jawabanSungguhan[i] = arrayofTebakan[i]
//                cek = true
//                toast("good guess")
//            }
//            if(cek){
//                result++
//                when (result) {
//                    1 -> imageView.setImageResource(R.drawable.hangman1)
//                    2 -> imageView.setImageResource(R.drawable.hangman2)
//                    3 -> imageView.setImageResource(R.drawable.hangman3)
//                    4 -> imageView.setImageResource(R.drawable.hangman4)
//                    5 -> imageView.setImageResource(R.drawable.hangman5)
//                    6 -> imageView.setImageResource(R.drawable.hangman6)
//                    7 -> imageView.setImageResource(R.drawable.hangman7)
//                    8 -> imageView.setImageResource(R.drawable.hangman8)
//                    9 -> imageView.setImageResource(R.drawable.hangman9)
//                    10 -> imageView.setImageResource(R.drawable.hangman10)
//                    11 -> imageView.setImageResource(R.drawable.hangman11)
//                }
//            }
//            //break
//        }
//        for (i in 0 until jawabanSungguhan.size) {
//            jawaban += jawabanSungguhan[i] + " "
//        }
//        textView2.text = jawaban
//        it.isEnabled = false
//    }
}