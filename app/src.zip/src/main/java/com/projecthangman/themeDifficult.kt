package com.projecthangman

class themeDifficult( var theme: String, var difficult: String, var array : Array<String>) {

    //difficult = arrayOf("easy","medium","hard")
    //var difficult = difficult

    val bodies = arrayOf("eye","ear","hip","eyebrows","pupil","teeth","fingers","tongue","shoulder")
    val things = arrayOf("bed","pen","ice","motor","watch","ruler","handphone","computer","chalkboard")
    val animals = arrayOf("cat","ant","dog","caterpillar","birds","alligator","whale","kangaroo","snakes")


}